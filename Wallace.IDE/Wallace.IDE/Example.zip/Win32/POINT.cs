﻿using System;
using System.Runtime.InteropServices;

namespace Wallace.IDE.Win32
{
    /// <summary>
    /// The POINT structure defines the x- and y- coordinates of a point.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct POINT
    {
        #region Fields

        /// <summary>
        /// The x-coordinate of the point.
        /// </summary>
        public int x;

        /// <summary>
        /// The y-coordinate of the point.
        /// </summary>
        public int y;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="x">x.</param>
        /// <param name="y">y.</param>
        public POINT(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        #endregion
    }
}
