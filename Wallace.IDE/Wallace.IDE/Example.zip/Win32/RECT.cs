﻿using System;
using System.Runtime.InteropServices;

namespace Wallace.IDE.Win32
{
    /// <summary>
    /// The RECT structure defines the coordinates of the upper-left and lower-right corners of a rectangle.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct RECT
    {
        #region Fields

        /// <summary>
        /// The x-coordinate of the upper-left corner of the rectangle.
        /// </summary>
        int left;

        /// <summary>
        /// The y-coordinate of the upper-left corner of the rectangle.
        /// </summary>
        int top;

        /// <summary>
        /// The x-coordinate of the lower-right corner of the rectangle.
        /// </summary>
        int right;

        /// <summary>
        /// The y-coordinate of the lower-right corner of the rectangle.
        /// </summary>
        int bottom;

        #endregion

        #region Methods

        /// <summary>
        /// Enlarges this Rectangle by the specified amount.
        /// </summary>
        /// <param name="width">The amount to inflate this Rectangle horizontally.</param>
        /// <param name="height">The amount to inflate this Rectangle vertically.</param>
        public void Inflate(int width, int height)
        {
            left = left - width;
            right = right + width;
            top = top - height;
            bottom = bottom + height;
        }

        #endregion
    }
}
