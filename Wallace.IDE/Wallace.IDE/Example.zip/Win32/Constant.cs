﻿using System;

namespace Wallace.IDE.Win32
{
    /// <summary>
    /// Definitions for constants used in unmanaged code.
    /// </summary>
    internal static class Constant
    {
        /// <summary>
        /// Sent to a window when the size or position of the window is about to change. An application can use this 
        /// message to override the window's default maximized size and position, or its default minimum or maximum 
        /// tracking size.
        ///
        /// A window receives this message through its WindowProc function.
        /// </summary>
        public const int WM_GETMINMAXINFO = 0x0024;
    }
}
