﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Wallace.IDE.UI
{
    /// <summary>
    /// The minimize button.
    /// </summary>
    public class WindowMinimizeButton : WindowCaptionButton
    {
        #region Methods

        /// <summary>
        /// Set visibility based on ResizeMode.
        /// </summary>
        protected override void Init()
        {
            base.Init();

            if (ParentWindow != null)
            {
                switch (ParentWindow.ResizeMode)
                {
                    case ResizeMode.NoResize:
                        Visibility = System.Windows.Visibility.Collapsed;
                        break;

                    default:
                        Visibility = System.Windows.Visibility.Visible;
                        break;
                }
            }
        }

        /// <summary>
        /// Draws the icon to display.
        /// </summary>
        /// <param name="arrangeBounds">The bounds to draw in.</param>
        /// <param name="canvas">The canvas to draw on.</param>
        /// <param name="centerX">The center along the x axis.</param>
        /// <param name="centerY">The center along the y axis.</param>
        /// <param name="squareLength">The length of the centered square.</param>
        /// <param name="squareHalfLength">The half length of the centered square.</param>
        /// <param name="squareLeft">The left position of the centered square.</param>
        /// <param name="squareRight">The right position of the centered square.</param>
        /// <param name="squareTop">The top position of the centered square.</param>
        /// <param name="squareBottom">The bottom position of the centered square.</param>
        protected override void DrawIcon(
            Size arrangeBounds,
            Canvas canvas,
            int centerX,
            int centerY,
            int squareLength,
            int squareHalfLength,
            int squareLeft,
            int squareRight,
            int squareTop,
            int squareBottom)
        {
            int shapePadding = 9;

            Line line = new Line();
            line.X1 = squareLeft + shapePadding;
            line.Y1 = squareBottom - shapePadding;
            line.X2 = squareRight - shapePadding;
            line.Y2 = squareBottom - shapePadding;
            line.Stroke = Foreground;
            line.StrokeThickness = 3;
            line.StrokeEndLineCap = PenLineCap.Flat;
            RenderOptions.SetEdgeMode(line, EdgeMode.Aliased);
            canvas.Children.Add(line);
        }

        /// <summary>
        /// Handle the button press.
        /// </summary>
        protected override void ButtonPress()
        {
            if (ParentWindow != null)
                ParentWindow.WindowState = WindowState.Minimized;
        }

        #endregion
    }
}
